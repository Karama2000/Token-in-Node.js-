// Importation des modules nécessaires
const express = require("express");
const { 
    getAllUsersController, 
    getUserByIdController, 
    createUserController, 
    deleteUserByIdController, 
    updateUserByIdController,
    loginUserController
} = require('../controllers/userController');

const userRouter = express.Router();

// Routes pour la gestion des utilisateurs

// Route pour créer un nouvel utilisateur
userRouter.post('/', createUserController);

// Route pour obtenir un utilisateur par son identifiant
userRouter.get('/:id', getUserByIdController);

// Route pour obtenir tous les utilisateurs
userRouter.get('/', getAllUsersController);

// Route pour supprimer un utilisateur par son identifiant
userRouter.delete('/:id', deleteUserByIdController);

// Route pour mettre à jour un utilisateur par son identifiant
userRouter.put('/:id', updateUserByIdController);

// Route pour la connexion
userRouter.post('/login', loginUserController);

// Exportation du routeur pour pouvoir l'utiliser dans d'autres fichiers
module.exports = userRouter;

